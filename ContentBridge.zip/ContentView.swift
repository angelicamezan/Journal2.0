import SwiftUI

struct ContentView: View {
    @State private var username = "" // Holds the username input.
    @State private var password = "" //Holds the user's password
    @State private var wrongUsername = 0 //tracks if username input is incorrect (not used in this page because the backend of the program isn't made)
    @State private var wrongPassword = 0 //tracks if password is incorrect (not used in this page bc backend code isnt done)
    @State private var showingLoginScreen = false
    // The body of the ContentView, describing its UI layout and components.
    var body: some View {
        NavigationStack {
            ZStack {
                Color.navy.ignoresSafeArea()// Sets the background color to blue and extends it to the edges.
                // Two overlaid circles creating a visual effect in the background. Saw it online & thought it would look cool
                Circle().scale(1.7).foregroundColor(.white.opacity(0.15))
                Circle().scale(1.35).foregroundColor(.white)
                
                VStack {
                    // Displays the app's logo.
                    Image("ClientBridge")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 100, height: 100)
                    // Displays the login title.
                    Text("Login")
                        .font(.largeTitle).bold().foregroundColor(.black).padding()
                    // Username input field.
                    TextField("Username...", text: $username)
                        .padding()
                        .frame(width: 300, height: 50)
                        .background(Color.black.opacity(0.05))
                        .cornerRadius(10)
                        .border(Color.black, width: CGFloat(wrongUsername))
                    // Password input field. Using secure field because it is a password
                    SecureField("Password...", text: $password)
                        .padding()
                        .frame(width: 300, height: 50)
                        .background(Color.black.opacity(0.05))
                        .cornerRadius(10)
                        .border(Color.black, width: CGFloat(wrongPassword))
                    // Login button -> leads straight to PostLoginView thing
                    Button("Login") {
                        showingLoginScreen = true
                    }
                    .foregroundColor(.white)
                    .frame(width: 100, height: 50)
                    .background(Color.navy)
                    .cornerRadius(10)
                }
            }
            .navigationBarHidden(true)
            // New navigation destination pattern
            // Specifies the destination to navigate to when 'showingLoginScreen' is true.
            .navigationDestination(isPresented: $showingLoginScreen) {
                LoginConfirmationView() // No need to pass 'username'
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

