import SwiftUI
extension Color {
    static let navy = Color(red: 0, green: 0, blue: 0.5) // Define navy color
}
struct LoginConfirmationView: View {
    var body: some View {
        VStack(spacing: 20) {
            HStack {
                Image("TopLogo") //made this change because I wanted this page to mimic the frame I had created originally on Canva
                    .resizable()
                    .scaledToFit()
                    .frame(width: 300, height: 100)
                    //.padding(.leading, 20)
                
            }
            //no longer useful because I changed the way it was supposed to look
            //Text("ClientBridge")
               // .font(.largeTitle)
               // .bold()
            
            // Notification/Post UI Component
            ZStack {
                RoundedRectangle(cornerRadius: 10)
                    .fill(Color.white.opacity(0.5))
                    .frame(height: 100)
                    .padding()
                
                Text("This is a mock Business Motivational Quote. ")
                    .padding()
                    .frame(width: 300, height: 100)
                    .background(Color.black.opacity(0.05))
                    .cornerRadius(10)
                    .overlay(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(Color.navy, lineWidth:6)
                        )
            }
            
            // Make a Post, Past Posts, Invite New Client Buttons
            VStack(spacing: 10) {
                Button("Templates") { }
                .buttonStyle(FilledButton())

                Button("Access Files") { }
                .buttonStyle(FilledButton())

            
            }
            
            Spacer()
            
            // Bottom Icon Buttons
            HStack {
                // Chat Button
                Button(action: {
                    // Future functionality for Chat
                }) {
                    VStack {
                        Image(systemName: "magnifyingglass")
                            .font(.title)
                        Text("Templates")
                            .font(.caption)
                    }
                }
                .foregroundColor(.navy)
                
                Spacer()
                
                // Dash (Home) Button
                Button(action: {
                    // Future functionality for Dash/Home
                }) {
                    VStack {
                        Image(systemName: "house")
                            .font(.title)
                        Text("Dash")
                            .font(.caption)
                    }
                }
                .foregroundColor(.navy)
                
                Spacer()
                
                // Files Button
                Button(action: {
                    // Future functionality for Files
                }) {
                    VStack {
                        Image(systemName: "cloud")
                            .font(.title)
                        Text("Files")
                            .font(.caption)
                    }
                }
                .foregroundColor(.navy)
            }
            .frame(maxWidth: .infinity)
            .padding(.horizontal, 20)
            .padding(.bottom, 20)
        }
        .navigationBarBackButtonHidden(true)
    }
}

// Custom button style for the bottom (trying to follow my design)
struct FilledButton: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .foregroundColor(.white)
            .padding()
            .background(Color.navy) // You can adjust this color to navy if you wish
            .cornerRadius(8)
            .scaleEffect(configuration.isPressed ? 0.95 : 1.0)
    }
}

struct LoginConfirmationView_Previews: PreviewProvider {
    static var previews: some View {
        LoginConfirmationView()
    }
}

// 
