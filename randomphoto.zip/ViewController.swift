//
//  ViewController.swift
//  RandomPhoto
//
//  Created by Angelica Meza on 4/24/24.
//

import UIKit

class ViewController: UIViewController {

    // MARK: - Properties

    // ImageView to display the random photo
    private let imageView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFill
        imageView.backgroundColor = .white
        return imageView
    }()
    
    // Button to fetch a new random photo
    private let button: UIButton = {
        let button = UIButton()
        button.backgroundColor = .white
        button.setTitle("RandomPhoto", for: .normal)
        button.setTitleColor(.black, for: .normal)
        return button
    }()
    
    // MARK: - Lifecycle Methods

    override func viewDidLoad() {
        super.viewDidLoad()
        // Set the background color of the view to pink
        view.backgroundColor = .systemPink
        
        // Add image view to the view hierarchy and set its frame
        view.addSubview(imageView)
        imageView.frame = CGRect(x: 0, y: 0, width: 300, height: 300)
        imageView.center = view.center
        
        // Add button to the view hierarchy and set its frame
        view.addSubview(button)
        
        // Fetch a random photo and set up the button's action
        getRandomPhoto()
        button.addTarget(self, action: #selector(didTapButton), for: .touchUpInside)
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        // Set the button's frame relative to the view's frame
        button.frame = CGRect(x: 30, y: view.frame.size.height-150-view.safeAreaInsets.bottom, width: view.frame.size.width-60, height: 55)
    }

    // MARK: - Button Action

    // Method called when the button is tapped
    @objc func didTapButton(){
        getRandomPhoto()
    }

    // MARK: - Helper Methods

    // Method to fetch a random photo from Unsplash and display it in the image view
    func getRandomPhoto() {
        let urlString = "https://source.unsplash.com/random/600x600"
        let url = URL(string: urlString)!
        
        // Attempt to fetch image data from the URL
        guard let data = try? Data(contentsOf: url) else {
            return
        }
        
        // Set the fetched image data to the image view
        imageView.image = UIImage(data:data)
    }
}

