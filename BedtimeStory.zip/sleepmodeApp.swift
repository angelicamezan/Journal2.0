//
//  sleepmodeApp.swift
//  sleepmode
//
//  Created by Angelica Meza on 4/24/24.
//

import SwiftUI

@main
struct sleepmodeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
