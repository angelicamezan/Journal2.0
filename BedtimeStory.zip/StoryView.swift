import SwiftUI

struct StoryDetailView: View {
    var story: Story
    
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            Spacer(minLength: 20)
            
            Text(story.title)
                .font(.largeTitle)
                .fontWeight(.bold)
                .foregroundColor(.white)
            
            Text(story.summary)
                .font(.title3)
                .foregroundColor(.yellow)
                .multilineTextAlignment(.leading)
                .padding()
            
            Spacer()
        }
        .background(LinearGradient(gradient: Gradient(colors: [ .black, .blue]), startPoint: .top, endPoint: .bottom))
        .edgesIgnoringSafeArea(.all)
    }
}

struct StoryDetailView_Previews: PreviewProvider {
    static var previews: some View {
        StoryDetailView(story: Story(title: "The Whispering Wind", summary: "Listen to the tales of the Wind and its travels around the world."))
    }
}
