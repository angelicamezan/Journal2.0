//
//  InternshipProbApp.swift
//  InternshipProb
//
//  Created by Angelica Meza on 4/24/24.
//

import SwiftUI

@main
struct InternshipProbApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
